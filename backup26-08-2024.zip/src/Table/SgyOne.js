import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, Sector } from 'recharts';
import apiClient from '../apiClient/ApiClient'; // Import your apiClient or define it here

const SgyOne = () => {
    const { id } = useParams(); // Get the id from URL parameters
    const [activeIndex, setActiveIndex] = useState(0);
    const [data, setData] = useState([]); // State to hold fetched data

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await apiClient.get(`/getAllformfields/${id}`);
                console.log("tableData", response.data.data)
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };

        fetchData();
    }, [id]); 

    const renderActiveShape = (props) => {
        const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, value, percent } = props;

        return (
            <g>
                <text
                    x={cx}
                    y={cy - 20}
                    dy={8}
                    textAnchor="middle"
                    fill={fill}
                    style={{ fontSize: '16px', fontWeight: 'bold' }}
                >
                    {payload.name}
                </text>
                <Sector
                    cx={cx}
                    cy={cy}
                    innerRadius={innerRadius}
                    outerRadius={outerRadius + 10}
                    startAngle={startAngle}
                    endAngle={endAngle}
                    fill={fill}
                    stroke="#000"
                    strokeWidth={2}
                    strokeOpacity={0.2}
                    style={{ filter: 'drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))' }}
                />
                <text
                    x={cx}
                    y={cy + 10}
                    textAnchor="middle"
                    fill="#333"
                    style={{ fontSize: '14px', fontWeight: 'bold' }}
                >
                    {`Count: ${value}`}
                </text>
                <text
                    x={cx}
                    y={cy + 30}
                    textAnchor="middle"
                    fill="#999"
                    style={{ fontSize: '12px' }}
                >
                    {`(${(percent * 100).toFixed(2)}%)`}
                </text>
            </g>
        );
    };

    const onPieEnter = (_, index) => {
        setActiveIndex(index);
    };

    // Pie Chart Data Preparation
    const totalBeneficiariesData = data.map(taluka => ({
        name: taluka.tal_Name,
        value: taluka.Sgy_total,
    }));

    const portalUploadsData = data.map(taluka => ({
        name: taluka.tal_Name,
        value: taluka.portal,
    }));

    const aadhaarAuthenticationData = data.map(taluka => ({
        name: taluka.tal_Name,
        value: taluka.adhar,
    }));

    // Custom Colors
    const COLORS_TOTAL = ['#1A3636', '#40534C', '#677D6A', '#D6BD98'];
    const COLORS_PORTAL = ['#1A3636', '#40534C', '#677D6A', '#D6BD98'];
    const COLORS_AADHAAR = ['#1A3636', '#40534C', '#677D6A', '#D6BD98'];

    return (
        <div className="p-6">
            {/* Table */}
            <div className="mb-8">
                <h2 className="text-xl font-bold m-4 text-center">संजय गांधी निराधार अनुदान योजना दिनांक 18/06/2024 अखेर डी.बी.टी पोर्टल कामाचा तपशिल</h2>
                <div className='overflow-x-auto'>
                    <table className="min-w-full bg-white border border-gray-300">
                        <thead className="bg-gray-200">
                            <tr>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">अ.क्र</th>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">Taluka Name</th>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">SGY Total Beneficiary</th>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">Portal Uploads</th>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">Aadhaar Authentication</th>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">Pralambit Upload</th>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">Portal Upload</th>
                                <th className="py-1 px-6 border-t-0 border-l border-r border-gray-300 text-center">Upload %</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((item) => (
                                <tr key={item.id}>
                                    <td className="py-1 px-6 border border-gray-300">{item.id}</td>
                                    <td className="py-1 px-6 border border-gray-300">{item.tal_Name}</td>
                                    <td className="py-1 px-6 border border-gray-300">{item.Sgy_total}</td>
                                    <td className="py-1 px-6 border border-gray-300">{item.portal}</td>
                                    <td className="py-1 px-6 border border-gray-300">{item.adhar}</td>
                                    <td className="py-1 px-6 border border-gray-300">{item.pralambitUpload}</td>
                                    <td className="py-1 px-6 border border-gray-300">{item.portalUpload}</td>
                                    <td className="py-1 px-6 border border-gray-300">{item.uploadPercent}</td>
                                </tr>   
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Pie Charts */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Total Beneficiaries Pie Chart */}
                <div className="flex flex-col items-center shadow-xl">
                    <h3 className="text-lg font-bold text-center mb-4 ">Total Beneficiaries</h3>
                    <ResponsiveContainer width={300} height={300}>
                        <PieChart>
                            <Pie
                                activeIndex={activeIndex}
                                activeShape={renderActiveShape}
                                data={totalBeneficiariesData}
                                dataKey="value"
                                nameKey="name"
                                outerRadius="80%"
                                innerRadius="60%"
                                onMouseEnter={onPieEnter}
                            >
                                {totalBeneficiariesData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS_TOTAL[index % COLORS_TOTAL.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                            <Legend verticalAlign="bottom" />
                        </PieChart>
                    </ResponsiveContainer>
                </div>

                {/* Portal Uploads Pie Chart */}
                <div className="flex flex-col items-center shadow-xl">
                    <h3 className="text-lg font-bold text-center mb-4">Portal Uploads</h3>
                    <ResponsiveContainer width={300} height={300}>
                        <PieChart>
                            <Pie
                                activeIndex={activeIndex}
                                activeShape={renderActiveShape}
                                data={portalUploadsData}
                                dataKey="value"
                                nameKey="name"
                                outerRadius="80%"
                                innerRadius="60%"
                                onMouseEnter={onPieEnter}
                            >
                                {portalUploadsData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS_PORTAL[index % COLORS_PORTAL.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                            <Legend verticalAlign="bottom" />
                        </PieChart>
                    </ResponsiveContainer>
                </div>

                {/* Aadhaar Authentication Pie Chart */}
                <div className="flex flex-col items-center shadow-xl">
                    <h3 className="text-lg font-bold text-center mb-4">Aadhaar Authentication</h3>
                    <ResponsiveContainer width={300} height={300}>
                        <PieChart>
                            <Pie
                                activeIndex={activeIndex}
                                activeShape={renderActiveShape}
                                data={aadhaarAuthenticationData}
                                dataKey="value"
                                nameKey="name"
                                outerRadius="80%"
                                innerRadius="60%"
                                onMouseEnter={onPieEnter}
                            >
                                {aadhaarAuthenticationData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS_AADHAAR[index % COLORS_AADHAAR.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                            <Legend verticalAlign="bottom" />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

export default SgyOne;
