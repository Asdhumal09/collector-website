import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import ArrowForwardIosSharpIcon from "@mui/icons-material/ArrowForwardIosSharp";
import MuiAccordion from "@mui/material/Accordion";
import MuiAccordionSummary from "@mui/material/AccordionSummary";
import MuiAccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import TopBar from "../TopBar/TopBar";
import { Box } from "@mui/material";
import { Link, useParams } from "react-router-dom";
import apiClient from "../apiClient/ApiClient";

// Styled components for Accordion
const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  "&:not(:last-child)": {
    borderBottom: 0,
  },
  "&::before": {
    display: "none",
  },
}));

const AccordionSummary = styled((props) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: "0.9rem" }} />}
    {...props}
  />
))(({ theme }) => ({
  backgroundColor:
    theme.palette.mode === "dark"
      ? "rgba(255, 255, 255, .05)"
      : "rgba(0, 0, 0, .03)",
  flexDirection: "row-reverse",
  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
    transform: "rotate(90deg)",
  },
  "& .MuiAccordionSummary-content": {
    marginLeft: theme.spacing(1),
  },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
  borderTop: "1px solid rgba(0, 0, 0, .125)",
}));

export default function CustomizedAccordions() {
  const { id } = useParams(); // Extract the id parameter from the URL
  const [expanded, setExpanded] = useState([]);
  const [yojanas, setYojanas] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await apiClient.get("/getAllYojna_subyojna");
        const data = response.data.data;
        setYojanas(data);

        // Set all panels to be expanded by default
        const allPanels = data.map((_, index) => `panel${index}`);
        setExpanded(allPanels);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? [panel] : []);
  };

  return (
    <>
      <TopBar />
      <Box
        sx={{
          background: "#fff",
          boxShadow: "0px 0px 12px #d7d7d763",
          padding: { xs: 0, sm: 4 },
          width: { sm: "90%", xs: "82%" },
          marginLeft: { sm: "6.5%", xs: "12%" },
          marginTop: { sm: "6.5%", xs: "12%" },
          padding: "2rem 0rem",
        }}
      >
        <Box
          sx={{
            width: "100%",
            padding: { xs: "0rem 1rem", sm: "0rem 2rem" },
          }}
        >
          <Typography
            variant="h2"
            textAlign={"center"}
            className="ff_yatra"
            sx={{
              fontSize: { xs: "1.6rem", sm: "2rem", md: "2.5rem" },
              paddingRight: { xs: 0, sm: 10 },
              marginBottom: "2%",
            }}
          >
            योजना
          </Typography>

          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              flexWrap: "wrap",
              gap: "16px", // Space between the accordions
              width: "100%",
              justifyContent: "space-between",
            }}
          >
            {yojanas.map((yojana, index) => (
              <Accordion
                key={index}
                expanded={expanded.includes(`panel${index}`)}
                onChange={handleChange(`panel${index}`)}
                sx={{ flex: "1 1 30%", maxWidth: "30%" }} // Adjust to fit three accordions side by side
              >
                <AccordionSummary
                  sx={{ backgroundColor: "rgb(101 210 255 / 17%)" }}
                  aria-controls={`panel${index}-content`}
                  id={`panel${index}-header`}
                >
                  <Typography
                    className="ff_yatra"
                    sx={{ fontSize: { sm: "1.3rem", xs: "18px" } }}
                  >
                    {yojana.yojna_title}
                  </Typography>
                </AccordionSummary>
                {yojana.subyojnas.map((subyojana, subIndex) => (
                  <AccordionDetails
                    key={subIndex}
                    sx={{
                      cursor: "pointer",
                      transition: "0.5s",
                      "&:hover": {
                        backgroundColor: "rgb(200 200 200 / 17%)",
                      },
                    }}
                  >
                    <Link
                      to={`/tahasiltwo/${id}/tableone/${subyojana.subyojna_id}`} 
                      style={{ textDecoration: "none", color: "inherit" }}
                    >
                      <Typography
                        className="ff_baloo"
                        sx={{ fontSize: { sm: "1.2rem", xs: "16px" } }}
                      >
                        {subyojana.sub_yojna_title}
                      </Typography>
                    </Link>
                  </AccordionDetails>
                ))}
              </Accordion>
            ))}
          </Box>
        </Box>
      </Box>
    </>
  );
}
