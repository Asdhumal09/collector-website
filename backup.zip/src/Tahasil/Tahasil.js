import React, { useEffect, useState } from "react";
import { Box, CssBaseline, Typography, Button, Grid } from "@mui/material";
import { useNavigate } from "react-router-dom";
import apiClient from "../apiClient/ApiClient";
import TopBar from "../TopBar/TopBar";

const Tahasil = () => {
  const [talukas, setTalukas] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await apiClient.get("/getAllTaluka");
        console.log(response.data);
        if (Array.isArray(response.data)) {
          setTalukas(response.data);
        } else if (response.data && Array.isArray(response.data.data)) {
          setTalukas(response.data.data);
        } else {
          console.error("Unexpected response format:", response.data);
          setTalukas([]);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setTalukas([]);
      }
    };

    fetchData();
  }, []);

  const buttonWidth = 200;
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate("/tahasiltwo");
  };

  // Group talukas into rows of decreasing lengths
  const groupedTalukas = [
    talukas.slice(0, 4),
    talukas.slice(4, 7),
    talukas.slice(7, 9),
    talukas.slice(9, 10),
  ];

  return (
    <Box
      sx={{
        flexGrow: 1,
        p: 3,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        marginTop: { xs: "20px", sm: "50px" },
        marginLeft: "25px",
      }}
    >
      <CssBaseline />
      <Box
        sx={{
          background: "#fff",
          boxShadow: "0px 0px 12px #d7d7d763",
          padding: { xs: 0, sm: 4 },
          width: "94%",
        }}
      >
        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <Typography
            variant="h2"
            textAlign={"center"}
            className="ff_yatra"
            sx={{
              fontSize: { xs: "2rem", sm: "3rem", md: "4rem" },
              paddingRight: { xs: 0, sm: 10 },
            }}
          >
            तहसील कार्यालये, जालना
          </Typography>

          <Box
            pt={6}
            sx={{
              display: "flex",
              flexDirection: "column", // Ensures rows stack vertically
              alignItems: "center", // Center align rows horizontally
              paddingRight: { xs: "0", sm: "10" },
            }}
          >
            {groupedTalukas.map((group, groupIndex) => (
              <Grid
                container
                spacing={4}
                justifyContent="center"
                key={groupIndex}
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  mb: 2, // Margin bottom between rows
                }}
              >
                {group.map((taluka) => (
                  <Grid item key={taluka.id}>
                    <Button
                      onClick={handleNavigate}
                      className="ff_yatra"
                      variant="contained"
                      sx={{
                        height: 60,
                        fontSize: 20,
                        width: buttonWidth,
                        background:
                          taluka.status == 2
                            ? "linear-gradient(43deg, #FFCC70 0%, #C850C0 46%, #4158D0 100%)"
                            : "linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(0,147,255,1) 0%, rgba(0,212,255,1) 100%)",
                        transition: "background 0.3s, transform 0.3s",
                        "&:hover": {
                          background:
                          taluka.status == 2 
                          ? "linear-gradient(43deg, #FFCC70 0%, #C850C0 46%, #4158D0 100%)":
                            "linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(0,147,255,1) 100%)",
                          transform: "scale(1.05)",
                        },
                      }}
                    >
                      {taluka.taluka_title}
                    </Button>
                  </Grid>
                ))}

              </Grid>
            ))}
          </Box>
        </Box>
      </Box>
      <TopBar />
    </Box>
  );
};

export default Tahasil;


