import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import ArrowForwardIosSharpIcon from "@mui/icons-material/ArrowForwardIosSharp";
import MuiAccordion from "@mui/material/Accordion";
import MuiAccordionSummary from "@mui/material/AccordionSummary";
import MuiAccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import TopBar from "../TopBar/TopBar";
import { Box } from "@mui/material";
import { Link } from "react-router-dom";
import apiClient from "../apiClient/ApiClient";

const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  "&:not(:last-child)": {
    borderBottom: 0,
  },
  "&::before": {
    display: "none",
  },
}));

const AccordionSummary = styled((props) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: "0.9rem" }} />}
    {...props}
  />
))(({ theme }) => ({
  backgroundColor:
    theme.palette.mode === "dark"
      ? "rgba(255, 255, 255, .05)"
      : "rgba(0, 0, 0, .03)",
  flexDirection: "row-reverse",
  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
    transform: "rotate(90deg)",
  },
  "& .MuiAccordionSummary-content": {
    marginLeft: theme.spacing(1),
  },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
  borderTop: "1px solid rgba(0, 0, 0, .125)",
}));

export default function CustomizedAccordions() {
  const [expanded, setExpanded] = useState(false);
  const [yojanas, setYojanas] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await apiClient.get("/getAllYojna_subyojna");
        console.log(response.data.data);
        const data = response.data.data;
        setYojanas(data);

        // Set the default expanded panel to the first one if available
        if (data.length > 0) {
          setExpanded(`panel0`); // Open the first panel by default
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const getTableRoute = (subyojanaId) => {
    // Example routing logic; adjust as needed
    if (subyojanaId === 1) return `/sgyTwo/${subyojanaId}`;
    if (subyojanaId === 2) return `/sgyOne/${subyojanaId}`;
    if (subyojanaId === 3) return `/sgyThree/${subyojanaId}`;
    return `/sgyFour/${subyojanaId}`; // Default route
  };

  return (
    <>
      <TopBar />
      <Box
        sx={{
          background: "#fff",
          boxShadow: "0px 0px 12px #d7d7d763",
          padding: { xs: 0, sm: 4 },
          width: { sm: "90%", xs: "82%" },
          marginLeft: { sm: "6.5%", xs: "12%" },
          marginTop: { sm: "6.5%", xs: "12%" },
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          padding: "2rem 0rem",
        }}
      >
        <Box
          sx={{
            width: { xs: "100%", sm: "80%", padding: "0rem 1rem" },
          }}
        >
          <Typography
            variant="h2"
            textAlign={"center"}
            className="ff_yatra"
            sx={{
              fontSize: { xs: "1.6rem", sm: "2rem", md: "2.5rem" },
              paddingRight: { xs: 0, sm: 10 },
              marginBottom: "2%",
            }}
          >
            योजना
          </Typography>

          {yojanas.map((yojana, index) => (
            <Accordion
              key={index}
              expanded={expanded === `panel${index}`}
              onChange={handleChange(`panel${index}`)}
            >
              <AccordionSummary
                sx={{ backgroundColor: "rgb(101 210 255 / 17%)" }}
                aria-controls={`panel${index}-content`}
                id={`panel${index}-header`}
              >
                <Typography
                  className="ff_yatra"
                  sx={{ fontSize: { sm: "1.3rem", xs: "18px" } }}
                >
                  {yojana.yojna_title}
                </Typography>
              </AccordionSummary>
              {yojana.subyojnas.map((subyojana, subIndex) => (
                <AccordionDetails
                  key={subIndex}
                  sx={{
                    cursor: "pointer",
                    transition: "0.5s",
                    "&:hover": {
                      backgroundColor: "rgb(200 200 200 / 17%)",
                    },
                  }}
                >
                  <Link
                    to={getTableRoute(subyojana.subyojna_id)} // Conditional navigation
                    style={{ textDecoration: "none", color: "inherit" }}
                  >
                    <Typography
                      className="ff_baloo"
                      sx={{ fontSize: { sm: "1.2rem", xs: "16px" } }}
                    >
                      {subyojana.sub_yojna_title}
                    </Typography>
                  </Link>
                </AccordionDetails>
              ))}
            </Accordion>
          ))}
        </Box>
      </Box>
    </>
  );
}
